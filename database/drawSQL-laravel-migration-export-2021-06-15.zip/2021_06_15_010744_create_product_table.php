<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('product', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('name');
            $table->integer('product_category_id');
            $table->integer('warehouse_id');
            $table->string('mfg_date');
            $table->string('exp_date');
            $table->integer('quantity');
            $table->integer('sell_price');
            $table->integer('supplier_price');
            $table->string('model');
            $table->string('sku');
            $table->integer('supplier_id');
            $table->string('img');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product');
    }
}
